""" A Functional Breakfast """

def make_omelette():
    print('Mixing the ingredients')
    print('Pouring the mixture into a frying pan')
    print('Cooking the first side')
    print('Flipping it!')
    print('Cooking the other side')
    omelette = 'a tasty omelette'
    return omelette

def make_pancake():
    print('Mixing the ingredients')
    print('Pouring the mixture into a frying pan')
    print('Cooking the first side')
    print('Flipping it!')
    print('Cooking the other side')
    pancake = 'a delicious pancake'
    return pancake
