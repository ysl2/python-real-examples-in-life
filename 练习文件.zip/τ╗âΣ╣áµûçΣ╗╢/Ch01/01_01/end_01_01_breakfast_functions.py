""" A Functional Breakfast """

def make_omelette():
    print('Mixing the ingredients')
    print('Pouring the mixture into a frying pan')
    print('Cooking the first side')
    print('Flipping it!')
    print('Cooking the other side')
    omelette = 'a tasty omelette'
    return omelette

# make two omelettes
omelette1 = make_omelette()
omelette2 = make_omelette()

print(omelette1)
print(omelette2)
