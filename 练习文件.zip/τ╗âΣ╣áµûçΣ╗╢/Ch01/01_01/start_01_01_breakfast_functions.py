""" A Functional Breakfast """

print('Mixing the ingredients')
print('Pouring the mixture into a frying pan')
print('Cooking the first side')
print('Flipping it!')
print('Cooking the other side')
omelette = 'a tasty omelette'
