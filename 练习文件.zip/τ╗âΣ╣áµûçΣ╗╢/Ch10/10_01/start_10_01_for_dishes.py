""" Loading the Dishwasher """

# dirty dishes in the sink
sink = ['bowl','plate','cup']

for dish in sink:
    print('Putting {} in the dishwasher'.format(dish))
